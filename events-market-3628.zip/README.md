# Events Market Dataset

This dataset package contains structured metadata and summary for the Events Market (NextMSC Report 3628).